Short Project 6
 
 * @author Aarya Vardhan Reddy Paakaala AXP170019
 * @author Shivaprakash Sivagurunathan SXS180104

Binary Search Tree Implementation


Methods:
 find - find method returns the entry where the element is found or where find failed)
 add  - Add x to tree. If tree contains a node with same key, replace element by x
 remove - Remove x from tree, Return x if found, otherwise return null
 get - Is there an element that is equal to x in the tree? Element in tree that is equal to x is returned, null otherwise.
 contains - Is x contained in tree? return true if found, else false
 min - returns the minimum element in BinarySearchTree
 max - returns the minimum element in BinarySearchTree
 splice - Splicing out -removing the parent- linking the parent and the child of the entry
 toArray - Create an array with the elements using in-order traversal of tree

Compile - javac BinarySearchTree.java
Run - java BinarySearchTree

ADD - Input a positive number to add to the tree
REMOVE - Input a negative number to remove that element from the tree