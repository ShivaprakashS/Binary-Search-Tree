/**
 * Short Project 6
 * 
 * @author Aarya Vardhan Reddy Paakaala
 * @author Shivaprakash Sivagurunathan
 */

package sxs180104;

import java.util.Comparator;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Stack;


public class BinarySearchTree<T extends Comparable<? super T>> implements Iterable<T> {
    static class Entry<T> {
        T element;
        Entry<T> left, right;
       // Constructor for Entry Class
        public Entry(T x, Entry<T> left, Entry<T> right) {
            this.element = x;
	        this.left = left;
	        this.right = right;
	    
        }
        // Constructor with element only for Entry Class (no children)
        public Entry(T x)
        {
        	this.element=x;
        	this.left=null;
        	this.right=null;
        }
    }
    
    Entry<T> root; // root of BinarySearchTree
    int size; // size of BinarySearchTree
    Stack<Entry<T>> s=new Stack<>(); // Stack to maintain the parent information along the path

    // Constructor for BinarySearchTree
    public BinarySearchTree() {
	root = null;
	size = 0;
    }
    
    
    /**
     * find method returns the entry where the element is found or where find failed
	 * @param an element x to be found 
	 * @return entry where the element is found
	 */
    public Entry<T> find(T x)
    {
    	
    	s.push(null);
    	Entry<T> t=find(root,x);
    	return t;
    }
    
    /**
	 * Find method begins from the entry T which is generally root which is the first parameter
	 * @param t the Entry from which the search begins
	 * @param an element x to be found 
	 * @return the entry where the element is found
	 * find(x) utility method used for finding the entry where element is present
	 */
    public Entry<T> find(Entry<T> root, T x)
    {
    	// When the element is found or when the first entry is null
    	if(root==null || root.element.compareTo(x)==0)
    	{
    		return root;
    	}
    	while(true)
    	{
    		// When element to be searched is less than root.element
    		if(x.compareTo(root.element)==-1)
    		{
    			// When root.left is null (no left subtree)
    			if(root.left==null)
    			{
    				break;
    			}
    			// When root.left is not null (left subtree present)
    			else
    			{
    				s.push(root);
    				root=root.left;
    			}
    		}
    		// When element to be searched is equal to root.element, found
    		else if(x.compareTo(root.element)==0)
    		{
    			break;
    		}
    		// When element to be searched is greater than root.element
    		else
    		{
    			// When root.right is null (no right subtree)
    			if(root.right==null)
    			{
    				break;
    			}
    			// When root.right is not null (right subtree present)
    			else
    			{
    				s.push(root);
    				root=root.right;
    			}
    		}
    	}
    	return root;
    }

    /**
	 * Is x contained in tree?
	 * @param an element x to be searched
	 * @return return true if found, else false
	 */
    public boolean contains(T x) {
	Entry<T> t=find(root,x);
	if((t==null) || x.compareTo(t.element) != 0)
    {
	return false;
    }
    else
    {
	return true;
    }
    }

    
    /**
	 * Is there an element that is equal to x in the tree?
	 * @param an element x to be searched
	 * @return Element in tree that is equal to x is returned, null otherwise.
	 */
    public T get(T x) {
    	Entry<T> t=find(root,x);
    	if((t==null) || x.compareTo(t.element) != 0)
    {
    	return null;
    }
    else
    {
    	return x;
    }
    }
    
    /**
	 * Add x to tree. If tree contains a node with same key, replace element by x. 
	 * Returns true if x is a new element added to tree.
	 * @param an element x to be added
	 * @return return true if element is added, else false
	 */
    public boolean add(T x) {
    	// When the size is 0, tree is empty, find method not invoked
    	if(size==0)
    	{
    		root=new Entry<T>(x);
    		size=1;
    		return true;
    	}
    	// When the tree is not empty
    	else
    	{
    		// Find method
    		Entry<T> t=find(x);
    		// If tree contains a node with same key, replace element by x
    		if(x.compareTo(t.element) == 0)
    		{
    			t.element=x;
    			return false;
    		}
    		// If element to be added less than t.element, then add should be performed in the left subtree.
    		else if(x.compareTo(t.element) ==-1)
    		{
    		t.left=new Entry<T>(x);	
    		}
    		// If element to be added greater than t.element, then add should be performed in the right subtree.
    		else
    		{
    			t.right=new Entry<T>(x);
    		}
    		size++;
    	}
	return true;
    }

   
    /**
	 * Remove x from tree
	 * Return x if found, otherwise return null
	 * @param an element x to be removed
	 * @return Return x if found, otherwise return null
	 */
    public T remove(T x) {
    	// if tree is empty, then return null
    	if(root==null)
    	{
    		return null;
    	}
    	// else find method
    	Entry<T> t=find(x);
    	// element found at the entry t
    	T telement = t.element; 
    	// if not found, return null
        if (x.compareTo(t.element) != 0) 
        {
        	return null;
        }
        // when t.left is null or t.right is null that is at-most one child
    	if((t.left==null) || t.right==null)
        {
	    splice(t);
        }
    	// when both left and right child present, two child
		else
		{
			s.push(t);
			// minimum in the right subtree
			Entry<T> minr=find(t.right,x);
			t.element=minr.element;
			// splicing out minr
			splice(minr);
		}
    	size--;
		return telement;
	    }
    
    /**
	 * Splicing out -removing the parent- linking the parent and the child of the entry
	 * Precondition: 
	 * 	1. t has at-most one child 
	 * 	2. Stack s has path from root to t
	 * @param entry t
	 */
    public void splice(Entry<T> t)
        {
    	Entry<T> parent=s.peek(); // parent of t
    	Entry<T> child=t.left!=null?t.left:t.right; // t has at-most one child
    	// when t is the root
    	if(parent==null)
    	{
    		root=child;
    	}
    	// when t is the left child
    	else if(parent.left==t)
    	{
    		parent.left=child;
    	}
    	// when t is the right child
    	else
    	{
    		parent.right=child;
    	}
    }
    
    // returns the minimum element in BinarySearchTree
    public T min() {
	if(size==0)
	{
		return null;
	}
	Entry<T> t=root;
	// minimum should be leftmost in left, traverse through the left subtree
	while(t.left!=null)
	{
		t=t.left;
	}
	return t.element;
    }

    // returns the minimum element in BinarySearchTree
    public T max() {
    	if(size==0)
    	{
    		return null;
    	}
    	Entry<T> t=root;
    	// maximum should be rightmost in right, traverse through the right subtree
    	while(t.right!=null)
    	{
    		t=t.right;
    	}
    	return t.element;
    }

    // Create an array with the elements using in-order traversal of tree
    public Comparable[] toArray() {
	Comparable[] arr = new Comparable[size];

	if (root == null) return null;
	
	Stack<Entry<T>> s = new Stack<Entry<T>>();
	int i=0;
	Entry<T> t = root;
	int length=s.size();
	//left,root,right inorder traversal
	while (t != null || length > 0) {
		while (t != null) {
			s.push(t);
			t = t.left;	
		}
		t = s.pop();
		arr[i] = t.element;
		i++;
		t = t.right;
	}
	return arr;
    }


// Start of Optional problem 2

    /** Optional problem 2: Iterate elements in sorted order of keys
	Solve this problem without creating an array using in-order traversal (toArray()).
     */
    public Iterator<T> iterator() {
	return null;
    }

    // Optional problem 2.  Find largest key that is no bigger than x.  Return null if there is no such key.
    public T floor(T x) {
        return null;
    }

    // Optional problem 2.  Find smallest key that is no smaller than x.  Return null if there is no such key.
    public T ceiling(T x) {
        return null;
    }

    // Optional problem 2.  Find predecessor of x.  If x is not in the tree, return floor(x).  Return null if there is no such key.
    public T predecessor(T x) {
        return null;
    }

    // Optional problem 2.  Find successor of x.  If x is not in the tree, return ceiling(x).  Return null if there is no such key.
    public T successor(T x) {
        return null;
    }

// End of Optional problem 2

    public static void main(String[] args) {
	BinarySearchTree<Integer> t = new BinarySearchTree<>();
        Scanner in = new Scanner(System.in);
        while(in.hasNext()) {
            int x = in.nextInt();
            if(x > 0) {
                System.out.print("Add " + x + " : ");
                t.add(x);
                t.printTree();
            } else if(x < 0) {
                System.out.print("Remove " + x + " : ");
                t.remove(-x);
                t.printTree();
            } else {
                Comparable[] arr = t.toArray();
                System.out.print("Final: ");
                for(int i=0; i<t.size; i++) {
                    System.out.print(arr[i] + " ");
                }
                System.out.println();
                return;
            }           
        }
    }


    public void printTree() {
	System.out.print("[" + size + "]");
	printTree(root);
	System.out.println();
    }

    // Inorder traversal of tree
    void printTree(Entry<T> node) {
	if(node != null) {
	    printTree(node.left);
	    System.out.print(" " + node.element);
	    printTree(node.right);
	}
    }

}
/*
Sample input:
1 3 5 7 9 2 4 6 8 10 -3 -6 -3 0

Output:
Add 1 : [1] 1
Add 3 : [2] 1 3
Add 5 : [3] 1 3 5
Add 7 : [4] 1 3 5 7
Add 9 : [5] 1 3 5 7 9
Add 2 : [6] 1 2 3 5 7 9
Add 4 : [7] 1 2 3 4 5 7 9
Add 6 : [8] 1 2 3 4 5 6 7 9
Add 8 : [9] 1 2 3 4 5 6 7 8 9
Add 10 : [10] 1 2 3 4 5 6 7 8 9 10
Remove -3 : [9] 1 2 4 5 6 7 8 9 10
Remove -6 : [8] 1 2 4 5 7 8 9 10
Remove -3 : [8] 1 2 4 5 7 8 9 10
Final: 1 2 4 5 7 8 9 10 

*/
